a = 3
def fucntion():
    a = 6
    b = 7

