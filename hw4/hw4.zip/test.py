hello = 1

def f(c, b):
    a = b

def b(m, t):
    a = t

b = 6






























