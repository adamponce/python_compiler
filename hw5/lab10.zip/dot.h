#ifndef DOT_H
#define DOT_H

void print_graph(struct tree *t, char *filename);

#endif