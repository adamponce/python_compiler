assignment = 1
